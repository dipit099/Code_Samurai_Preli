GET http://localhost:8000
change DB credentials


**go to your branch first**
git checkout -b dipit

**git-pull-cmd**

git fetch origin
git pull origin main


**git-push-cmd**
git add .
git commit -m "your message here"
git push -u origin dipit



